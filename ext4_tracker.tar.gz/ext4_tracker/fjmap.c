// SPDX-License-Identifier: GPL-2.0
/*
 * fs/ext4/fjmap.c
 *
 * Fragmented Journal Map (FJM) for ext4.
 *
 * Allows transactions to use non-contiguous journal blocks.  A
 * per-block entry array and per-transaction descriptor list record the
 * mapping; an on-disk index block written just before each JBD2 commit
 * record enables recovery after a crash.
 *
 * JBD2 source files are NEVER touched.  All hooks are in ext4 code.
 * If the FJM cannot be initialised (or the journal is absent) every
 * function is a safe no-op and callers fall back to standard JBD2
 * behaviour.
 *
 * Locking order:
 *   ext4_fjmap.lock   (spinlock, innermost)
 *   — held only for very short critical sections
 *   — NEVER held while calling any JBD2 function
 */

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/bitmap.h>
#include <linux/buffer_head.h>
#include <linux/crc32.h>
#include <linux/jbd2.h>

#include "ext4.h"
#include "ext4_jbd2.h"
#include "fjmap.h"

/* ------------------------------------------------------------------ */
/* Internal helpers                                                     */
/* ------------------------------------------------------------------ */

/* Convert an absolute journal block number to a bitmap/entry index. */
static inline unsigned long blk_to_idx(struct ext4_fjmap *fjmap,
					unsigned long blkno)
{
	return blkno - fjmap->j_first;
}

/*
 * Find the fjmap_txn with the given tid.
 * Called with fjmap->lock held.
 */
static struct fjmap_txn *fjmap_find_txn_locked(struct ext4_fjmap *fjmap,
					       tid_t tid)
{
	struct fjmap_txn *txn;

	list_for_each_entry(txn, &fjmap->txn_list, list) {
		if (txn->tid == tid)
			return txn;
	}
	return NULL;
}

/*
 * Append a journal block number to a fjmap_txn's blk_list, growing
 * the array if needed.
 * Called with fjmap->lock held.
 * Returns 0 on success, -ENOMEM on failure.
 */
static int fjmap_txn_append_block(struct fjmap_txn *txn, __u32 blkno)
{
	__u32 *new_list;
	__u32  new_cap;

	if (txn->n_blocks >= txn->blk_list_cap) {
		new_cap  = txn->blk_list_cap ? txn->blk_list_cap * 2 : 8;
		/* Drop the lock temporarily for the allocation. */
		/* NOTE: caller must hold lock only around bitmap ops;
		 * here we are called from alloc_block which already
		 * holds the lock.  We use GFP_ATOMIC to stay atomic. */
		new_list = krealloc(txn->blk_list,
				    new_cap * sizeof(__u32), GFP_ATOMIC);
		if (!new_list)
			return -ENOMEM;
		txn->blk_list     = new_list;
		txn->blk_list_cap = new_cap;
	}
	txn->blk_list[txn->n_blocks++] = blkno;
	return 0;
}

/* 
 * Callback bound to journal->j_alloc_block_callback to intercept 
 * block mappings directly inside JBD2's write loop.
 */
static int ext4_fjmap_alloc_block_cb(struct journal_s *journal, unsigned long long *blkno_out)
{
	struct super_block *sb = journal->j_private;
	tid_t tid;
	unsigned long long relative_blk = 0;
	int err;

	if (journal->j_committing_transaction)
		tid = journal->j_committing_transaction->t_tid;
	else if (journal->j_running_transaction)
		tid = journal->j_running_transaction->t_tid;
	else
		return -ENODATA;

	/* Let FJM pick a fragmented block */
	err = ext4_fjmap_alloc_block(sb, tid, 0, &relative_blk);
	if (err)
		return err;

	/* Pass the relative fragmented block back to JBD2, 
	 * which will map it to disk via its internal bmap. */
	*blkno_out = relative_blk;
	return 0;
}


/*
 * Callback bound to journal->j_free_txn_callback so JBD2 can notify FJM
 * when a finished transaction is being freed.
 */
static void ext4_fjmap_free_txn_cb(struct journal_s *journal, tid_t tid)
{
	struct super_block *sb = journal->j_private;

	if (!sb)
		return;

	ext4_fjmap_free_txn(sb, tid);
}


/* ------------------------------------------------------------------ */
/* Public API                                                           */
/* ------------------------------------------------------------------ */

/**
 * ext4_fjmap_init - allocate the FJM at mount time.
 */
int ext4_fjmap_init(struct super_block *sb)
{
	struct ext4_sb_info *sbi = EXT4_SB(sb);
	struct ext4_fjmap   *fjmap;
	journal_t           *journal = sbi->s_journal;
	unsigned long        n_blocks;
	int err;

	/* No journal or mount option disabled → FJM is a no-op */
	if (!journal || !test_opt2(sb, FJM)) {
		sbi->s_fjmap = NULL;
		return 0;
	}

	fjmap = kzalloc(sizeof(*fjmap), GFP_KERNEL);
	if (!fjmap)
		return -ENOMEM;

	spin_lock_init(&fjmap->lock);
	INIT_LIST_HEAD(&fjmap->txn_list);

	/*
	 * j_last and j_first are set by jbd2_journal_load().
	 * j_first is the first usable journal block (after the
	 * journal superblock); j_last is one past the last.
	 */
	fjmap->j_first  = journal->j_first;
	n_blocks         = journal->j_last - journal->j_first;
	fjmap->n_blocks  = n_blocks;

	/* Allocate the free-block bitmap */
	fjmap->bitmap_words = BITS_TO_LONGS(n_blocks);
	fjmap->bitmap = kcalloc(fjmap->bitmap_words,
				sizeof(unsigned long), GFP_KERNEL);
	if (!fjmap->bitmap)
		goto err_bitmap;

	/* Allocate the per-block entry array */
	fjmap->entries = kcalloc(n_blocks, sizeof(struct fjmap_entry),
				 GFP_KERNEL);
	if (!fjmap->entries)
		goto err_entries;

	/* Set bit 0 so JBD2 never allocates our index block (j_first) */
	set_bit(0, fjmap->bitmap);

	sbi->s_fjmap = fjmap;
	
	/* Wire up the allocator callback inside JBD2 */
	journal->j_alloc_block_callback = ext4_fjmap_alloc_block_cb;
	journal->j_free_txn_callback = ext4_fjmap_free_txn_cb;

	ext4_msg(sb, KERN_INFO,
		 "FJM: initialised, tracking %lu journal blocks "
		 "(j_first=%lu j_last=%lu)",
		 n_blocks, journal->j_first, journal->j_last);
	return 0;

err_entries:
	kfree(fjmap->bitmap);
err_bitmap:
	kfree(fjmap);
	return -ENOMEM;
}

/**
 * ext4_fjmap_destroy - free all FJM memory at unmount time.
 */
void ext4_fjmap_destroy(struct super_block *sb)
{
	struct ext4_sb_info *sbi   = EXT4_SB(sb);
	struct ext4_fjmap   *fjmap = sbi->s_fjmap;
	struct fjmap_txn    *txn, *tmp;
	journal_t           *journal = sbi->s_journal;

	if (!fjmap)
		return;

	/* Detach callbacks before freeing FJM memory. */
	if (journal) {
		journal->j_alloc_block_callback = NULL;
		journal->j_free_txn_callback = NULL;
	}


	list_for_each_entry_safe(txn, tmp, &fjmap->txn_list, list) {
		list_del(&txn->list);
		kfree(txn->blk_list);
		kfree(txn);
	}

	kfree(fjmap->entries);
	kfree(fjmap->bitmap);
	kfree(fjmap);
	sbi->s_fjmap = NULL;
	ext4_msg(sb, KERN_INFO, "FJM: destroyed");
}

/**
 * ext4_fjmap_begin_txn - create a per-transaction descriptor.
 */
void ext4_fjmap_begin_txn(struct super_block *sb, tid_t tid)
{
	struct ext4_fjmap *fjmap = EXT4_SB(sb)->s_fjmap;
	struct fjmap_txn  *txn;

	if (!fjmap)
		return;

	txn = kzalloc(sizeof(*txn), GFP_NOFS);
	if (!txn) {
		ext4_msg(sb, KERN_WARNING,
			 "FJM: failed to alloc txn descriptor for tid=%u", tid);
		return;
	}

	txn->tid = tid;
	INIT_LIST_HEAD(&txn->list);

	spin_lock(&fjmap->lock);
	/* Avoid duplicates (handle re-entry) */
	if (!fjmap_find_txn_locked(fjmap, tid)) {
		list_add_tail(&txn->list, &fjmap->txn_list);
		ext4_msg(sb, KERN_INFO, "FJM: Tracking new transaction tid=%u", tid);
	}
	else {
		spin_unlock(&fjmap->lock);
		kfree(txn);
		return;
	}
	spin_unlock(&fjmap->lock);
}

/**
 * ext4_fjmap_alloc_block - find a free journal block for a transaction.
 *
 * Returns 0 and sets *blkno_out on success.
 * Returns -ENOSPC when the bitmap is full (caller uses JBD2 fallback).
 * Returns -ENODEV when FJM is disabled.
 */
int ext4_fjmap_alloc_block(struct super_block *sb, tid_t tid, __u32 seq,
			   unsigned long long *blkno_out)
{
	struct ext4_fjmap  *fjmap = EXT4_SB(sb)->s_fjmap;
	struct fjmap_txn   *txn;
	unsigned long       idx;
	unsigned long long  blkno;
	int                 ret = 0;

	if (!fjmap)
		return -ENODEV;

	spin_lock(&fjmap->lock);

	/* Find the first free bit in the bitmap */
	idx = find_first_zero_bit(fjmap->bitmap, fjmap->n_blocks);
	if (idx >= fjmap->n_blocks) {
		/* Journal is completely occupied by FJM-tracked blocks */
		spin_unlock(&fjmap->lock);
		return -ENOSPC;
	}

	/* Mark the block as used */
	set_bit(idx, fjmap->bitmap);
	blkno = fjmap->j_first + idx;

	/* Fill in the per-block entry */
	fjmap->entries[idx].tid         = tid;
	fjmap->entries[idx].seq         = seq;
	fjmap->entries[idx].journal_blk = (__u32)blkno;

	/* Append to the transaction's block list */
	txn = fjmap_find_txn_locked(fjmap, tid);
	if (txn) {
		ret = fjmap_txn_append_block(txn, (__u32)blkno);
		if (ret) {
			/* Allocation failure: roll back the bitmap bit */
			clear_bit(idx, fjmap->bitmap);
			memset(&fjmap->entries[idx], 0,
			       sizeof(fjmap->entries[idx]));
			spin_unlock(&fjmap->lock);
			return ret;
		}
	}
	/* If txn is NULL the transaction did not call begin_txn first;
	 * the block is still tracked in entries[] but won't appear in
	 * a blk_list.  This is harmless: commit_txn won't write an
	 * FJM block for an unknown tid. */

	ext4_msg(sb, KERN_INFO, "FJM: Allocated journal blk=%llu for tid=%u seq=%u", 
	         blkno, tid, seq);

	spin_unlock(&fjmap->lock);

	*blkno_out = blkno;
	return 0;
}

/**
 * ext4_fjmap_commit_txn - write the on-disk FJM index block.
 *
 * This function builds a single journal-resident buffer containing
 * fjmap_ondisk_hdr + N fjmap_ondisk_entry records and submits it
 * synchronously.  It is called from __ext4_journal_stop() just before
 * jbd2_journal_stop().
 *
 * Implementation notes:
 *  - We use __getblk() on the journal device to get a buffer for the
 *    NEXT free journal block (j_head), then submit it.  We do NOT
 *    advance j_head ourselves — that is JBD2's job.  Instead we write
 *    to the block at (j_first) which we permanently reserve as the
 *    FJM index location.  This is the simplest, safest prototype
 *    approach (Option A from the plan).
 *  - We protect j_first from being allocated by the bitmap by marking
 *    bit 0 as permanently set in ext4_fjmap_init().
 */
void ext4_fjmap_commit_txn(struct super_block *sb, tid_t tid)
{
	struct ext4_sb_info    *sbi   = EXT4_SB(sb);
	struct ext4_fjmap      *fjmap = sbi->s_fjmap;
	struct fjmap_txn       *txn;
	struct fjmap_ondisk_hdr *hdr;
	struct fjmap_ondisk_entry *entry_ptr;
	struct buffer_head     *bh;
	unsigned long		index_blkno;
	__u32                   commit_order;
	__u32			n_entries;
	__u32			i;
	__u32			csum;
	size_t			needed_bytes;

	if (!fjmap)
		return;

	spin_lock(&fjmap->lock);
	txn = fjmap_find_txn_locked(fjmap, tid);
	if (!txn || txn->n_blocks == 0) {
		spin_unlock(&fjmap->lock);
		return;
	}

	n_entries    = txn->n_blocks;
	commit_order = fjmap->next_commit_order++;
	txn->commit_order = commit_order;
	spin_unlock(&fjmap->lock);

	/* Limit entries to what fits in one block */
	if (n_entries > FJMAP_MAX_ENTRIES_PER_BLOCK) {
		ext4_msg(sb, KERN_WARNING,
			 "FJM: tid=%u has %u blocks, truncating index to %u",
			 tid, n_entries, FJMAP_MAX_ENTRIES_PER_BLOCK);
		n_entries = FJMAP_MAX_ENTRIES_PER_BLOCK;
	}

	needed_bytes = sizeof(*hdr) +
		       (size_t)n_entries * sizeof(struct fjmap_ondisk_entry);
	if (needed_bytes > sb->s_blocksize) {
		ext4_msg(sb, KERN_WARNING,
			 "FJM: index block overflow (need %zu, block=%u)",
			 needed_bytes, sb->s_blocksize);
		return;
	}

	/*
	 * Use bitmap index 0 (= j_first) as the permanent FJM index block.
	 * We set bit 0 in ext4_fjmap_init() so JBD2 can't allocate it.
	 */
	index_blkno = fjmap->j_first;

	bh = __getblk(sbi->s_journal->j_dev, index_blkno, sb->s_blocksize);
	if (!bh) {
		ext4_msg(sb, KERN_ERR,
			 "FJM: failed to get buffer for index block %lu",
			 index_blkno);
		return;
	}

	lock_buffer(bh);
	memset(bh->b_data, 0, sb->s_blocksize);

	/* Fill in the header */
	hdr              = (struct fjmap_ondisk_hdr *)bh->b_data;
	hdr->magic       = cpu_to_le32(FJMAP_MAGIC);
	hdr->n_entries   = cpu_to_le32(n_entries);
	hdr->commit_order = cpu_to_le32(commit_order);
	hdr->checksum    = 0;  /* zeroed for CRC computation */

	/* Fill in the per-block entries */
	entry_ptr = (struct fjmap_ondisk_entry *)(hdr + 1);

	spin_lock(&fjmap->lock);
	txn = fjmap_find_txn_locked(fjmap, tid);
	if (!txn) {
		spin_unlock(&fjmap->lock);
		unlock_buffer(bh);
		brelse(bh);
		return;
	}
	for (i = 0; i < n_entries; i++) {
		entry_ptr[i].tid          = cpu_to_le32(txn->tid);
		entry_ptr[i].seq          = cpu_to_le32(i);
		entry_ptr[i].journal_blk  = cpu_to_le32(txn->blk_list[i]);
		entry_ptr[i].commit_order = cpu_to_le32(commit_order);
	}
	spin_unlock(&fjmap->lock);

	/* Compute and store CRC32 over the full block */
	csum = crc32_le(~0U, bh->b_data, sb->s_blocksize);
	hdr->checksum = cpu_to_le32(csum);

	set_buffer_uptodate(bh);
	set_buffer_dirty(bh);
	bh->b_end_io = end_buffer_write_sync;

	get_bh(bh);
	submit_bh(REQ_OP_WRITE | REQ_SYNC, bh);
	wait_on_buffer(bh);

	if (!buffer_uptodate(bh))
		ext4_msg(sb, KERN_ERR,
			 "FJM: I/O error writing index block for tid=%u", tid);
	else
		ext4_msg(sb, KERN_INFO,
			 "FJM: committed tid=%u commit_order=%u (%u blocks)",
			 tid, commit_order, n_entries);

	brelse(bh);
}

/**
 * ext4_fjmap_free_txn - release FJM resources after a checkpoint.
 *
 * Caller is responsible for ensuring that JBD2 has already checkpointed
 * the transaction (i.e. all data is safely on the main filesystem).
 */
void ext4_fjmap_free_txn(struct super_block *sb, tid_t tid)
{
	struct ext4_fjmap *fjmap = EXT4_SB(sb)->s_fjmap;
	struct fjmap_txn  *txn;
	__u32              i;
	unsigned long      idx;

	if (!fjmap)
		return;

	spin_lock(&fjmap->lock);
	txn = fjmap_find_txn_locked(fjmap, tid);
	if (!txn) {
		spin_unlock(&fjmap->lock);
		return;
	}

	/* Free all journal blocks belonging to this transaction */
	for (i = 0; i < txn->n_blocks; i++) {
		idx = blk_to_idx(fjmap, txn->blk_list[i]);
		if (idx < fjmap->n_blocks) {
			clear_bit(idx, fjmap->bitmap);
			memset(&fjmap->entries[idx], 0,
			       sizeof(fjmap->entries[idx]));
		}
	}

	ext4_msg(sb, KERN_INFO, "FJM: Freed %u blocks for checkpointed tid=%u", 
	         txn->n_blocks, tid);

	list_del(&txn->list);
	spin_unlock(&fjmap->lock);

	kfree(txn->blk_list);
	kfree(txn);
}

/**
 * ext4_fjmap_dump - dump FJM state to kernel log (debugging helper).
 */
void ext4_fjmap_dump(struct super_block *sb)
{
	struct ext4_fjmap *fjmap = EXT4_SB(sb)->s_fjmap;
	struct fjmap_txn  *txn;
	unsigned long      used;

	if (!fjmap) {
		ext4_msg(sb, KERN_INFO, "FJM: not initialised");
		return;
	}

	spin_lock(&fjmap->lock);
	used = bitmap_weight(fjmap->bitmap, (unsigned int)fjmap->n_blocks);
	ext4_msg(sb, KERN_INFO,
		 "FJM: j_first=%lu n_blocks=%lu used=%lu free=%lu",
		 fjmap->j_first, fjmap->n_blocks, used,
		 fjmap->n_blocks - used);

	list_for_each_entry(txn, &fjmap->txn_list, list) {
		ext4_msg(sb, KERN_INFO,
			 "FJM:   txn tid=%u n_blocks=%u commit_order=%u",
			 txn->tid, txn->n_blocks, txn->commit_order);
	}
	spin_unlock(&fjmap->lock);
}


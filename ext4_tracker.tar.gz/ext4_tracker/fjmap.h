/* SPDX-License-Identifier: GPL-2.0 */
/*
 * fs/ext4/fjmap.h
 *
 * Fragmented Journal Map (FJM): allows ext4 journal transactions to
 * occupy non-contiguous blocks in the journal area.  A per-block entry
 * array and per-transaction descriptor table record which blocks belong
 * to which transaction and in what order, so that recovery can
 * reconstruct the mapping after a crash.
 *
 * Design goals:
 *   - JBD2 source files are NEVER modified.
 *   - If FJM is not initialised (no journal, or init failure) all code
 *     paths fall back to standard JBD2 behaviour transparently.
 *   - A single spinlock protects all in-memory FJM state; it is never
 *     held across any JBD2 call.
 */

#ifndef _EXT4_FJMAP_H
#define _EXT4_FJMAP_H

#include <linux/types.h>
#include <linux/spinlock.h>
#include <linux/list.h>
#include <linux/jbd2.h>

/* ------------------------------------------------------------------ */
/* Magic / limits                                                       */
/* ------------------------------------------------------------------ */

#define FJMAP_MAGIC		0xF17A4A91U

/*
 * Maximum number of per-block entries that fit in a single 4 KiB
 * on-disk index block after the header:
 *   (4096 - sizeof(fjmap_ondisk_hdr)) / sizeof(fjmap_ondisk_entry)
 * With the structures below that is (4096 - 16) / 16 = 255.
 */
#define FJMAP_MAX_ENTRIES_PER_BLOCK	255U

/* ------------------------------------------------------------------ */
/* On-disk structures (stored in a dedicated journal block)             */
/* ------------------------------------------------------------------ */

/**
 * struct fjmap_ondisk_hdr - header written at the start of the FJM
 *                           index block.
 *
 * Layout of the on-disk block:
 *   [fjmap_ondisk_hdr][fjmap_ondisk_entry * n_entries]
 *
 * The block is appended to the journal *after* JBD2 has written the
 * transaction's metadata blocks but *before* the JBD2 commit record.
 * This ordering means:
 *   - If the machine crashes before the FJM block lands → the FJM block
 *     is absent; recovery ignores it and uses the standard JBD2
 *     descriptor block.
 *   - If the FJM block lands but the commit record does not → JBD2
 *     aborts the transaction anyway (no commit = no replay).
 *   - Only committed transactions (commit record present) have their
 *     FJM blocks honoured during recovery.
 */
struct fjmap_ondisk_hdr {
	__le32	magic;		/* FJMAP_MAGIC */
	__le32	n_entries;	/* number of fjmap_ondisk_entry records */
	__le32	commit_order;	/* global monotonic commit counter */
	__le32	checksum;	/* CRC32 of the full block (with this = 0) */
};

/**
 * struct fjmap_ondisk_entry - one record per journal block used by the
 *                             committed transaction.
 */
struct fjmap_ondisk_entry {
	__le32	tid;		/* JBD2 transaction ID (t_tid) */
	__le32	seq;		/* sequence of this block within the txn */
	__le32	journal_blk;	/* absolute journal block number */
	__le32	commit_order;	/* same as header (for cross-check) */
};

/* ------------------------------------------------------------------ */
/* In-memory structures                                                 */
/* ------------------------------------------------------------------ */

/**
 * struct fjmap_entry - in-memory record for one journal block.
 *
 * Stored in the fjmap_entry[] array indexed by
 *   (journal_blk - journal->j_first).
 */
struct fjmap_entry {
	__u32	tid;		/* owning transaction ID; 0 = free */
	__u32	seq;		/* sequence within the transaction */
	__u32	journal_blk;	/* absolute journal block number */
};

/**
 * struct fjmap_txn - in-memory descriptor for one transaction.
 *
 * Kept in a singly-linked list anchored at ext4_fjmap.txn_list.
 * Created when ext4_fjmap_begin_txn() is called (at journal_start time)
 * and freed when ext4_fjmap_checkpoint_txn() indicates that JBD2 has
 * checkpointed all blocks of the transaction.
 */
struct fjmap_txn {
	__u32		tid;		/* JBD2 t_tid */
	__u32		n_blocks;	/* number of journal blocks allocated */
	__u32		commit_order;	/* global monotonic index */
	__u32		*blk_list;	/* ordered array of journal block nos. */
	__u32		blk_list_cap;	/* current allocation capacity */
	struct list_head list;		/* link in ext4_fjmap.txn_list */
};

/**
 * struct ext4_fjmap - top-level FJM manager.
 *
 * One instance per mounted filesystem; stored as ext4_sb_info.s_fjmap.
 * NULL means FJM is disabled (no journal, or initialisation failed).
 */
struct ext4_fjmap {
	/* Protects bitmap, entries[], txn_list, and next_commit_order */
	spinlock_t		lock;

	/* Free-block bitmap: bit N = journal block (j_first + N) */
	unsigned long		*bitmap;
	unsigned long		bitmap_words;	/* words in bitmap[] */
	unsigned long		n_blocks;	/* total journal blocks tracked */

	/* Per-block metadata, indexed by (blkno - j_first) */
	struct fjmap_entry	*entries;

	/* List of active / recently-committed fjmap_txn objects */
	struct list_head	txn_list;

	/* Monotonically increasing commit counter */
	__u32			next_commit_order;

	/* Journal first block (j_first) cached for index arithmetic */
	unsigned long		j_first;
};

/* ------------------------------------------------------------------ */
/* Function prototypes (implemented in fjmap.c)                        */
/* ------------------------------------------------------------------ */

/**
 * ext4_fjmap_init() - allocate and initialise the FJM at mount time.
 *
 * Called from ext4_load_journal() after jbd2_journal_load() succeeds.
 * Returns 0 on success, negative errno on fatal allocation failure
 * (caller should treat this as a mount error).
 */
int  ext4_fjmap_init(struct super_block *sb);

/**
 * ext4_fjmap_destroy() - free all FJM memory at unmount time.
 *
 * Safe to call even if s_fjmap is NULL.
 */
void ext4_fjmap_destroy(struct super_block *sb);

/**
 * ext4_fjmap_begin_txn() - create a per-transaction descriptor.
 *
 * Called early in __ext4_journal_start_sb() after the JBD2 handle is
 * obtained and handle->h_transaction is valid.
 * No-op if s_fjmap is NULL.
 */
void ext4_fjmap_begin_txn(struct super_block *sb, tid_t tid);

/**
 * ext4_fjmap_alloc_block() - allocate one free journal block for a txn.
 *
 * Returns the absolute journal block number on success, or a negative
 * errno code on failure (caller must fall back to
 * jbd2_journal_next_log_block()).
 *
 * -ENOSPC is the normal "bitmap full" signal → use JBD2 fallback.
 * No-op / returns -ENODEV if s_fjmap is NULL.
 */
int  ext4_fjmap_alloc_block(struct super_block *sb, tid_t tid, __u32 seq,
			    unsigned long long *blkno_out);

/**
 * ext4_fjmap_commit_txn() - write the on-disk FJM index block for a txn.
 *
 * Called from __ext4_journal_stop() just before jbd2_journal_stop().
 * Writes a single journal block containing fjmap_ondisk_hdr + all
 * fjmap_ondisk_entry records for the current transaction.
 *
 * No-op if s_fjmap is NULL or if the transaction has no FJM-managed
 * blocks.
 */
void ext4_fjmap_commit_txn(struct super_block *sb, tid_t tid);

/**
 * ext4_fjmap_free_txn() - release FJM blocks after a checkpoint.
 *
 * Called from ext4_journal_callback when JBD2 signals that a
 * transaction has been checkpointed to the main filesystem.
 * No-op if s_fjmap is NULL.
 */
void ext4_fjmap_free_txn(struct super_block *sb, tid_t tid);

/**
 * ext4_fjmap_dump() - print FJM state to the kernel log (for debugging).
 */
void ext4_fjmap_dump(struct super_block *sb);

#endif /* _EXT4_FJMAP_H */


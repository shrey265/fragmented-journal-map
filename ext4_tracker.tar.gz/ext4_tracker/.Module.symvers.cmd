cmd_fs/ext4_tracker/Module.symvers :=  sed 's/ko$$/o/'  fs/ext4_tracker/modules.order | scripts/mod/modpost -m -a    -o fs/ext4_tracker/Module.symvers -e -i Module.symvers -T - 
